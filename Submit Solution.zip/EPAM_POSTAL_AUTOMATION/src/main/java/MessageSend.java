import dev.failsafe.internal.util.Assert;
import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

import static org.openqa.selenium.By.xpath;

public class MessageSend extends BasePage {

    private static final String SIGN_IN_SEARCH = "//a[@class='_yb_16hi5']";
    private static final String INPUT_FIRST_USER_LOGIN = "//input[@class='phone-no ']";
    private static final String COMPLETE_USERNAME = "//input[@id='login-signin']";
    private static final String PASSWORD_SEARCH = "//input[@type='password']";
    private static final String COMPLETE_PASSWORD = "//button[@type='submit']";

    //*********//

    private static final String GOTOMAILBOX = "//a[@class='_yb_17muv']";
    private static final String CREATENEWMESSAGE = "//a[@role='button']";
    private static final String FULLMESSAGETEXT = "Hello Anton is here, i am student of EPAM System";
    private static final String ANOTHERPOST = "currentChoise@gmail.com";
    private static final String MESSAGETO = "//*[@id='message-to-field']";
    private static final String ENTERTEXTINTOFIELD = "//*[@id='editor-container']/div[1]";
    private static final String SENDBUTTON = "//*[@id='mail-app-component']/div/div/div/div[2]/div[2]/div/button";
    private static final String SENDEDMESSAGE = "//div[@class='J_x o_h G_e C_Z1YRXYn']";
    private static final String SENDEDMESSAGE1 = "//div[text()='Hello Anton is here, i am student of EPAM System']";
    private static final String TYPEOFMESSAGE = "//*[@id='mail-app-component']/div/div/div/div[1]/div[3]/div/div/input";
    public MessageSend(WebDriver driver) {
        super(driver);
    }

    public void sendNewMessage() {
        driver.navigate().to("https://www.yahoo.com/?guccounter=1&guce_referrer=aHR0cHM6Ly9sb2dpbi55YWhvby5jb20v&guce_referrer_sig=AQAAAG1LulDEJ-_F2IUbGEd8nhZNrI-nQKgyZSRHXxkxdtazk0HJSb24Q0a95_xudEE68WnjlREAYfeCZkWnSCR2xWGCAkx-HxviFo7RQVts707Xzo1aIiRipB38KvUtNy1qs-AaRs9OJSRpBr6UWDo0mNVyFStwmFMv3kgdCU4PRBTc");
        driver.findElement(xpath(GOTOMAILBOX)).click(); // зайти в пошту
        driver.findElement(xpath(CREATENEWMESSAGE)).click(); // створити
        driver.findElement(xpath(MESSAGETO)).sendKeys(ANOTHERPOST); // кому
        driver.findElement(xpath(TYPEOFMESSAGE)).sendKeys("12345"); // тема
        driver.findElement(xpath(ENTERTEXTINTOFIELD)).sendKeys(FULLMESSAGETEXT); // текст смс
        driver.findElement(xpath(SENDBUTTON)).click(); // отправить
        driver.navigate().to("https://mail.yahoo.com/d/folders/2"); // переходим во вкладку отправленные
        driver.findElement(xpath(SENDEDMESSAGE1)).click(); // проверяем вкладку отправленные сообщения
    }
}
