import org.openqa.selenium.WebDriver;

import java.util.concurrent.TimeUnit;

import static org.openqa.selenium.By.xpath;

public class UserLoginPage extends BasePage{

    private static final String SIGN_IN_SEARCH = "//a[@class='_yb_16hi5']";
    private static final String INPUT_FIRST_USER_LOGIN = "//input[@class='phone-no ']";
    private static final String COMPLETE_USERNAME = "//input[@id='login-signin']";
    private static final String PASSWORD_SEARCH = "//input[@type='password']";
    private static final String COMPLETE_PASSWORD = "//button[@type='submit']";

    public UserLoginPage(WebDriver driver) {
        super(driver);
    }

    public void usernameField(final String keyword) {
        driver.findElement(xpath(SIGN_IN_SEARCH)).click();
        driver.findElement(xpath(INPUT_FIRST_USER_LOGIN)).sendKeys(keyword);
        driver.findElement(xpath(COMPLETE_USERNAME)).click();
    }

    public void userPasswordField(final String password) {
        driver.findElement(xpath(SIGN_IN_SEARCH)).click();
        driver.findElement(xpath(INPUT_FIRST_USER_LOGIN)).sendKeys("epamHomeWork_1");
        driver.findElement(xpath(COMPLETE_USERNAME)).click();
        driver.navigate().to("https://login.yahoo.com/account/challenge/password?.lang=en-US&src=homepage&pspid=2023538075&activity=ybar-signin&done=https%3A%2F%2Fwww.yahoo.com%2F&sessionIndex=QQ--&acrumb=ARWNmpAY&display=login&authMechanism=primary");
        // navigate я установил из-за сложности перехода на окно ввода пароля. (После ввода логина пользователя на почте Yahoo
        // Сервис не открывает следующую страницу и )
        driver.findElement(xpath(PASSWORD_SEARCH)).sendKeys(password);
        driver.findElement(xpath(COMPLETE_PASSWORD)).click();
    }

    public void verifyFalseUsername (final String fakeUsername) {
        driver.findElement(xpath(SIGN_IN_SEARCH)).click();
        driver.findElement(xpath(INPUT_FIRST_USER_LOGIN)).sendKeys(fakeUsername);
        driver.findElement(xpath(COMPLETE_USERNAME)).click();
    }
    }
