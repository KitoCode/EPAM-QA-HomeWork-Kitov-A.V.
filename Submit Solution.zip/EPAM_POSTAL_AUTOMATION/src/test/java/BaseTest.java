import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeTest;

import static io.github.bonigarcia.wdm.WebDriverManager.chromedriver;

public class BaseTest {
    private WebDriver driver;
    private static final String YAHOO_URL = "https://www.yahoo.com/";

    @BeforeTest
    public void profileSetUp() {
        chromedriver().setup();
    }

    @BeforeMethod
    public void testsSetUp() {
        driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get(YAHOO_URL);
    }

    public WebDriver getDriver() {
        return driver;
    }

    public UserLoginPage getUserLoginPage() {
        return new UserLoginPage(getDriver());
    }

    public MessageSend getMessageUserTest(){
        return new MessageSend(getDriver());
    }
    //@AfterMethod
    //public void tearDown() {
     //   driver.quit();
    //}
}
