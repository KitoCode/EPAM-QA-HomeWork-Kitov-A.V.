import org.checkerframework.checker.units.qual.C;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.Assert;
import org.testng.annotations.Test;

import static org.openqa.selenium.By.xpath;

public class MessageSendTest extends BaseTest {

    private static final String FINDTEXT = "//div[@dir='ltr']";

    @Test()
    public void checkMessageIsSend() {
        WebDriver driver = new ChromeDriver();
        getUserLoginPage().userPasswordField("10203040AAAbbb");
        getMessageUserTest().sendNewMessage();
        //WebElement e = driver.findElement(By.xpath(FINDTEXT)); // получаем сообщение из текста
        //String s = e.getText();
        //Assert.assertEquals(s, "Hello Anton is here, i am student of EPAM System");
    }
}
