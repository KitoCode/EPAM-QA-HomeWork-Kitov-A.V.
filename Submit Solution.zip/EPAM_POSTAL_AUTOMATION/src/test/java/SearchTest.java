import org.apache.commons.compress.compressors.pack200.Pack200CompressorInputStream;
import org.testng.Assert;
import org.testng.annotations.Test;

public class SearchTest extends BaseTest{
    private String USERNAME = "epamHomeWork_1@yahoo.com";
    private String PASSWORD = "10203040AAAbbb";
    private String FAKEUSER = "1234rfa109i@yahoo.com";

    @Test(priority = 1)
    public void checkUsernameInput() {
        getUserLoginPage().usernameField(USERNAME);
    }

    @Test(priority = 2)
    public void checkPasswordInput(){
        getUserLoginPage().userPasswordField(PASSWORD);
    }

    @Test(priority = 3)
    public void checkFalseUsername(){
        getUserLoginPage().verifyFalseUsername(FAKEUSER);
        Assert.assertNotEquals(USERNAME, FAKEUSER);
    }

}
